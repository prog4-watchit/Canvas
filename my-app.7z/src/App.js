import logo from './logo.svg';
import './App.css';
import Canvas from "./Canvas/canvasSettings"

function App() {
  return (
    <>
      <Canvas width={600} height={320} />
    </>
  );
}

export default App;
